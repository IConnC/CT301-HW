#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// George Krier
// gkrier

// NOTE: Suggested Functions

/*
OutputGeneration()
Input: 
    A String representing the Generation to output. This should be passed by Reference ex: String &gen
    An Int reprsenting the current Generation Count
    An Int reprsenting the width of the table
Returns: Nothing
Function:
    Prints out "Generation: 0" with a new line and prints out each row of the game table with a newline after each row end.

CalculateGeneration
Input:
    An Integer containing the width of each row
    A String Reference for the "Current" Generation EX: String &curr_gen
    A String Reference for the "Next" Generation EX: String &next_gen
Returns: Nothing
Function:
    For each cell in the table, perform the rules of the game of life on it.
    Count the number of Alive Neighbors and cross check that count with the rules of the Game Of Life
    Then update the cell information in the "next generation" string
*/
const static char ALIVE_CHARACTER = '*';
const static char DEAD_CHARACTER = ' ';


// Returns an integer array of all cells that are currently alive
int* GetLiveAdjacent(int width, const string &curr_gen, int index) {
    static int adjacent[8];
    int count = 0;

    for (int i=0; i<8; i++) {
        adjacent[i] = -1;
    }

    cout << "\nIndex: " << index << "\n";

    int curr_index;
    for (int row=index - 1; row < index + 2; row++) {
        for (int col=index - 1; col < index + 2; col++) {
            // Gets index of adjacent cells
            curr_index = ((col + width) % width + (((row + width) % width) * width));

            if (curr_index == index) continue;

            if (curr_gen[curr_index] == ALIVE_CHARACTER || true) {
                adjacent[count] = curr_index;
                count++;
                cout << " " << curr_index << ":" << curr_gen[curr_index];
            }
            
        }
    }

    cout << "\n";
    /*
    for (int i=0; i<8; i++) {
        cout << curr_gen[adjacent[i]] << " ";
    }

    cout << "\n";
    */

    return adjacent;
}

// Checks if the current cell should be alive or dead
bool CalculateIsAlive(int *adjacent, bool currently_alive) {

    int alive_neighbors = 0;

    for (int i=0; i < 8; i++) {
        if (adjacent[i] == -1) break;
        alive_neighbors++;
    }

    // A live cell with fewer than two live neighbors dies (underpopulation). (1)
    // A live cell with more than three live neighbors dies (overpopulation). (3)
    if (currently_alive && (alive_neighbors < 2 || alive_neighbors > 3)) return false;

    // A live cell with two or three live neighbors lives on to the next generation. (2)
    else if (currently_alive) return true;

    // A dead cell with exactly three live neighbors comes to life (rebirth). (4)
    if (!currently_alive && alive_neighbors == 3) return true;

    return false;
}

// Outputs the cells
void OutputGeneration(const string &gen, int generation_number, int width) {
    cout << "Generation: " << generation_number << "\n";
    for (int row=0; row < width; row++) {
        for (int col=0; col < width; col++) {
            cout << gen[col+(row*width)];
        }
        cout << "\n";
    }
}

// Calculates the next cell generation
void CalculateGeneration(int width, const string &curr_gen, string &next_gen) {

    int* adjacent_pointer;

    for (int row=0; row < width; row++) {
        for (int col=0; col < width; col++) {
            //GetLiveAdjacent(width, curr_gen, col+(row*width));
            adjacent_pointer = GetLiveAdjacent(width, curr_gen, col+(row*width));
            

            // Sets cells to dead or alive depending on 
            // Second argument checks to see if current cell is alive or not
            if (CalculateIsAlive(adjacent_pointer, (curr_gen[col+(row*width)] == ALIVE_CHARACTER))) {
                next_gen[col+(row*width)] = ALIVE_CHARACTER;
            } else {
                next_gen[col+(row*width)] = DEAD_CHARACTER;
            }
        }
    }
}


int main(int argc, char* argv[])
{
    if (argc < 2){
        cerr << argv[0] << " Usage:\n" << argv[0] << " filename\n\n" << "The filename passed should contain the following, the integer width of the table, the number of generations then a Width by Width table of characters for setting up the game\n" << endl;
        return -1;
    }
    string filename = argv[1];
    ifstream file_in(filename);
    string line;
    int width;
    int generations;
    file_in >> width >> generations;
    string game_table_alpha(width*width, DEAD_CHARACTER);
    string game_table_beta(width*width, DEAD_CHARACTER);
    getline(file_in, line);
    for (int row = 0; file_in && row < width; ++row){
        getline(file_in, line);
        for (int col = 0; col < width; ++col)
        {
            game_table_alpha[col+(row*width)] = line[col];
        }
    }

    for (int gen=0; gen < generations; gen++) {
        OutputGeneration(game_table_alpha, gen, width);
        CalculateGeneration(width, game_table_alpha, game_table_beta);
        game_table_alpha = game_table_beta;
    }

    //GetLiveAdjacent(width,game_table_alpha, 2);

    // NOTE: Your Code Starts Here
}